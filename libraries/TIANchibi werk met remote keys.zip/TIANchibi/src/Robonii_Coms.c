#include "src/Robonii_coms.h"
#include "TianChibi.h"
#include "HardwareSerial.h"


unsigned char Robonii_Remote_Key_Pressed()
{

if (Robonii_Remote_New_Message)
{
Robonii_Remote_New_Message = 0;
return Robonii_Remote_Keys;

}

return 0;
}

unsigned char Robonii_Service_Remote_Message(unsigned char *data)
{
 Robonii_Remote_Battery = data[2];
Robonii_Remote_Keys = data[1];

Robonii_Remote_LF = Robonii_Remote_Keys & REMOTE_LEFT_FORWARD;
Robonii_Remote_FR = Robonii_Remote_Keys &REMOTE_LEFT_BACKWARD;
 Robonii_Remote_RF = Robonii_Remote_Keys &REMOTE_RIGHT_FORWARD;
 Robonii_Remote_RR = Robonii_Remote_Keys &REMOTE_RIGHT_BACKWARD;
 Robonii_Remote_LT = Robonii_Remote_Keys &REMOTE_LEFT_TRIGGER;
 Robonii_Remote_RT = Robonii_Remote_Keys &REMOTE_RIGHT_TRIGGER;
 Robonii_Remote_Robonii_Remote_DubleTap = Robonii_Remote_Keys &REMOTE_FRONT_DOUBLE_TAP;
 
 if (Robonii_Remote_Keys==0)
 {
 Robonii_Remote_No_Key_Pressed = REMOTE_NONE;
 Robonii_Remote_Keys = REMOTE_NONE;
 }else
  {
  Robonii_Remote_No_Key_Pressed = 0;
  }
 


Robonii_Remote_New_Message = 1;
}


unsigned char Robonii_Parse_Msg(byte *data, unsigned char DataLength)
{
	MsgLength = data[0];
	if (DataLength != MsgLength)
	{
		return PARSE_ERROR_Length;
	}
	MsgCounter=data[3];
	MsgPANID = data[5] * 256 + data[4];
	
	unsigned char i=0;
	MsgSrcMac=0;
	MsgDstMac=0;
	for (i=8;i>0;i--)
	{
		MsgSrcMac = MsgSrcMac*256;
		MsgSrcMac = MsgSrcMac+data[5+i];
		MsgDstMac = MsgDstMac*256;
		MsgDstMac = MsgDstMac+data[5+8+i]	;
	}

	MsgDataHdr = data[22];
	MsgDataLength = data[23];
	MsgDataCounter = data[24];
	MsgDataDevType = data[25];
	MsgDataCRC = data[26];
	MsgDataptr = &data[27];
	
	unsigned char i3 = 0;
	for (i=27;i<MsgLength;i++)
	{
	MsgData[i3++] = data[i];
	}
	
	unsigned char CRC_TEST = Robonii_CalculateCRC(data,DataLength-1);
	
	if (CRC_TEST != data[DataLength-1])
	{
		//return PARSE_ERROR_CRC;
	}
	
	
	if ((MsgDataHdr== 0xA0)&&(MsgDataDevType==ROBONII_REMOTE_TYPE))
	{
		//Decode Remote Message
		Robonii_Service_Remote_Message(MsgDataptr);
		
	}
	
	
	if ((Robonii_Auto_Paired_Reply)&&(MsgDataHdr== 0xA5))
	{
		if ((MsgDstMac == OwnMac)||(PairedMac==0)||(OwnMac==0))
		{
			//Remote Request a header reply message from me
			#ifdef ROBONII_TEST			
			Robonii_Print_Msg();
			#endif			
			if ((PairedMac==0))
			{
				PairedMac = MsgSrcMac;
			#ifdef ROBONII_TEST			
				unsigned char macbuf[9];
				Serial.print("Don't have paired MAC. Taking this one...Own MAC: ");
				Robonii_MAC_to_char(OwnMac,macbuf);
				Serial.println("");
				Serial.print("Paired MAC: ");
				Robonii_MAC_to_char(PairedMac,macbuf);
				Serial.println("");
			#endif	
			}
			if ((OwnMac==0))
			{
				OwnMac=MsgDstMac;
			#ifdef ROBONII_TEST			
					unsigned char macbuf2[9];
					Serial.print("Don't have MAC. Taking this one... Own MAC: ");
					Robonii_MAC_to_char(OwnMac,macbuf2);
					Serial.println("");
					Serial.print("Paired MAC: ");
					Robonii_MAC_to_char(PairedMac,macbuf2);
					Serial.println("");
			#endif	
				
			}
			
			Robonii_sendRemoteMessagePairedAvailable();
		}
	}
	
	
	return PARSE_SUCSES;
}


void Robonii_SetAutoPairedReply(unsigned char NewSetting)
{
	Robonii_Auto_Paired_Reply =NewSetting;
}


void Robonii_SetOwnMac(uint64_t NewMac)
{
	OwnMac =NewMac;
}

void Robonii_SetPairedMac(uint64_t NewMac)
{
	OwnMac =NewMac;
}

/**
 * \brief Calculate CRC.
 *
 * This function is used to calculate the CRC for a message with a length smaller than 255 chars.
 * \param  *data The data pointer that points to a memory location.
 * \param  length The length of the data.
 * \return unsigned char The byte containing the CRC is returned.
*/
unsigned char Robonii_CalculateCRC(uint8_t *data, uint8_t length)
{
	unsigned char crcCalc = 0x00;
	for(uint8_t i=0; i< length; i++)
		crcCalc ^= data[i];

	return crcCalc;
}

void Robonii_addMAc(uint64_t MacToAdd,unsigned char *data, unsigned char *pos)
{
  int i = 0;
  
  for (i=0; i<8;i++)
  {
    data[(*pos)++]= MacToAdd%256;
    
    MacToAdd = MacToAdd/256;
  }
}

unsigned char Robonii_MsgCounter = 2;
unsigned char Robonii_MakeMessage(unsigned char *txBuffer, unsigned char *data, unsigned int dataLentgh)
{
  //8B 16 0 0 1 D5 25 0
 //uint64_t OwnMac =    0x25D5010000168B;
 
 //1 0 0 0 0 D5 25 0
// uint64_t PairedMac = 0x25D50000000001;
 
 //unsigned int Robonii_PANID = 0x22FE;
 
  byte buf2[127];
  unsigned char i=1;
  
  txBuffer[0] = 22+dataLentgh+1; //Header + data + crc
  txBuffer[i++] = 0x61;
  txBuffer[i++] = 0xCC;
  txBuffer[i++] =Robonii_MsgCounter++;
  
  
  txBuffer[i++] = Robonii_PANID%256;
  txBuffer[i++] = Robonii_PANID/256;
  
   Robonii_addMAc(OwnMac,txBuffer,&i);
  Robonii_addMAc(PairedMac,txBuffer,&i);
 
  
  int dataCount = 0;
  for (dataCount=0;dataCount<dataLentgh;dataCount++)
  {
  txBuffer[i++] =data[dataCount]  ;
  }
  
  unsigned char crc = Robonii_CalculateCRC(buf2,i);
  txBuffer[i++] = crc;
  return i;
}


void Robonii_sendRemoteMessagePairedAvailable()
{
  byte buf2[100];
  byte bufTX[100];
 
  unsigned char i=0;
   buf2[i++] = 0xA7;
  buf2[i++] = 0x00;
  buf2[i++] = 0xE3;
  
  buf2[i++] = 0x02;
  buf2[i++] = 0x00;
  //buf2[i++] = 0xA3;
 // unsigned char crc = CalculateCRC(buf2,i);
 // buf2[i++] = crc;
  unsigned char TXLength = 0;
 TXLength= Robonii_MakeMessage(bufTX,buf2,i);


  chibiTxRaw( bufTX, TXLength);
}

void Robonii_sendRemoteMessageControlTest()
{
  byte buf2[100];
  byte bufTX[100];
 
  unsigned char i=0;
   buf2[i++] = 0xA0;
  buf2[i++] = 0x13;
  buf2[i++] = 0xA3;
  
  buf2[i++] = 0x02;
  buf2[i++] = 0x5E;
  buf2[i++] = 0x0A;
  
   buf2[i++] = 0x51;
  buf2[i++] = 0x55;
  buf2[i++] = 0x15;
  
   buf2[i++] = 0x10;
  buf2[i++] = 0x00;
  buf2[i++] = 0x00;
  
   buf2[i++] = 0x04;
  buf2[i++] = 0x00;
  buf2[i++] = 0x11;
  
   buf2[i++] = 0x55;
  buf2[i++] = 0x54;
  buf2[i++] = 0x54;
  
    buf2[i++] = 0x45;
  buf2[i++] = 0x55;
  buf2[i++] = 0x54;
  
   buf2[i++] = 0x50;
  buf2[i++] = 0x01;
  buf2[i++] = 0x00;
  
 // buf2[i++] = 0xB9;
 // unsigned char crc = CalculateCRC(buf2,i);
 // buf2[i++] = crc;
  
  
   unsigned char TXLength = 0;
 TXLength= Robonii_MakeMessage(bufTX,buf2,i);
  chibiTxRaw( bufTX, TXLength);
}

void Robonii_MAC_to_char(uint64_t mac, unsigned char *DestinationBuf)
{
unsigned char i=0;
unsigned char i2=0;
Robonii_addMAc(mac,DestinationBuf, &i);

for (i=0; i<8;i++)
{
Serial.print(DestinationBuf[i], HEX);
Serial.print(" ");
}

DestinationBuf[8] = 0;
}

void Robonii_Print_Msg()
{
unsigned char macbuf[9];
Serial.print("Own MAC: ");
Robonii_MAC_to_char(OwnMac,macbuf);
Serial.println("");
Serial.print("Paired MAC: ");
Robonii_MAC_to_char(PairedMac,macbuf);
Serial.println("");

Serial.print("Dest MAC: ");
Robonii_MAC_to_char(MsgDstMac,macbuf);
Serial.println("");
Serial.print("Source MAC: ");
Robonii_MAC_to_char(MsgSrcMac,macbuf);
Serial.println("");

Serial.print("Msg Header: ");
Serial.println(MsgDataHdr, HEX);
Serial.print("Msg Data Lenght: ");
Serial.println(MsgDataLength, HEX);
Serial.print("Msg Counter: ");
Serial.println(MsgDataCounter, HEX);
Serial.print("Msg Device Type: ");
Serial.println(MsgDataDevType, HEX);
Serial.print("Msg data CRC: ");
Serial.println(MsgDataCRC, HEX);
Serial.print("Data: ");
unsigned char i = 0;
for (i=0; i<MsgDataLength;i++)
{
Serial.print(MsgData[i], HEX);
Serial.print(" ");
}
Serial.println("--");

}



