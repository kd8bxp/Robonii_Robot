#ifndef ROBONII_COMS_H
#define CHB_SPI_H

#include "types.h"
#include <avr/io.h>

#define ROBONII_TEST			


#define PARSE_SUCSES 	0
#define PARSE_ERROR		1
#define PARSE_ERROR_Length	5
#define PARSE_ERROR_CRC		6

#define ROBONII_ROBOT_TYPE		2
#define ROBONII_REMOTE_TYPE		1

#define REMOTE_LEFT_BACKWARD	(0x02)
#define REMOTE_LEFT_FORWARD		(0x01)
#define REMOTE_LEFT_TRIGGER		(0x04)
#define REMOTE_RIGHT_BACKWARD	(0x10)
#define REMOTE_RIGHT_FORWARD	(0x08)
#define REMOTE_RIGHT_TRIGGER	(0x20)
#define REMOTE_FRONT_DOUBLE_TAP	(0x40)		
#define REMOTE_NONE  (0x80)


  //8B 16 0 0 1 D5 25 0
 uint64_t OwnMac =    0x25D5010000168B;
 
 //1 0 0 0 0 D5 25 0
 uint64_t PairedMac = 0x25D50000000001;

 unsigned char Robonii_Auto_Paired_Reply = 1;
 
 
 
unsigned char Robonii_MakeMessage(unsigned char *txBuffer, unsigned char *data, unsigned int dataLentgh);
void Robonii_SetPairedMac(uint64_t NewMac);
void Robonii_SetOwnMac(uint64_t NewMac);
unsigned char Robonii_Parse_Msg(unsigned char *data, unsigned char DataLength);
unsigned char Robonii_CalculateCRC(uint8_t *data, uint8_t length);
void Robonii_sendRemoteMessagePairedAvailable();
void Robonii_sendRemoteMessageControlTest();
void Robonii_Print_Msg();
void Robonii_addMAc(uint64_t MacToAdd,unsigned char *data, unsigned char *pos);
void Robonii_MAC_to_char(uint64_t mac, unsigned char *DestinationBuf);

unsigned char Robonii_Remote_Key_Pressed();


unsigned int Robonii_PANID = 0x22FE;


unsigned int MsgPANID=0;
uint64_t MsgSrcMac=0;	// Message Source Mac
uint64_t MsgDstMac=0;	// Message Destination Mac
unsigned char MsgLength = 0;
unsigned char MsgCounter = 0;
unsigned char MsgCRC = 0;

unsigned char MsgDataHdr = 0;
unsigned char MsgDataLength = 0;
unsigned char MsgDataCounter = 0;
unsigned char MsgDataDevType = 0;
unsigned char MsgDataCRC = 0;
byte MsgData[127];
byte *MsgDataptr;
 
unsigned char Robonii_Remote_Battery = 0;
unsigned char Robonii_Remote_Keys = 0;
unsigned char Robonii_Remote_LF = 0;
unsigned char Robonii_Remote_FR = 0;
unsigned char Robonii_Remote_RF = 0;
unsigned char Robonii_Remote_RR = 0;
unsigned char Robonii_Remote_LT = 0;
unsigned char Robonii_Remote_RT = 0;
unsigned char Robonii_Remote_Robonii_Remote_DubleTap = 0;
unsigned char Robonii_Remote_New_Message = 0;
unsigned char Robonii_Remote_No_Key_Pressed = 0;


#endif